# Data

Place the project data files in this folder.

Recommended files:

- `products.csv`
- `customers.csv`
- `stores.csv`
- `raw_transactions.csv`

Do not commit confidential, proprietary, or personally identifiable customer data.

The current repository intentionally does not fabricate a dataset. Add the real/synthetic dataset you used for the project and update the README with its source and row counts.
