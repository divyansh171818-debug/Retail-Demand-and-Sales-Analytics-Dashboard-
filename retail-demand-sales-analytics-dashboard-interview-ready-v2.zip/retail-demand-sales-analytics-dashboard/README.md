# Retail Demand & Sales Analytics Dashboard

> **End-to-end SQL + Power BI analytics project for retail sales, customer behavior, product demand, and inventory-risk analysis.**

[![MySQL](https://img.shields.io/badge/Database-MySQL-4479A1?logo=mysql&logoColor=white)](https://www.mysql.com/)
[![Power BI](https://img.shields.io/badge/BI-Power%20BI-F2C811?logo=powerbi&logoColor=black)](https://powerbi.microsoft.com/)
[![SQL](https://img.shields.io/badge/Language-SQL-336791)](#sql-analysis)

## Project Overview

This project demonstrates an end-to-end analytics workflow that transforms retail transaction data into decision-ready sales and inventory insights.

The workflow is:

**Raw Data → MySQL Data Model → SQL Analysis → Demand & Inventory Metrics → Power BI → Business Insights**

The project is designed to demonstrate practical SQL and BI skills that are useful for **Data Analyst, Business Analyst, and Supply Chain Analytics** interviews.

---

## Business Problem

Retail teams need to answer questions such as:

- How are revenue and profit changing over time?
- Which products and categories drive sales?
- Which customers and regions contribute the most revenue?
- Which products are fast-, medium-, or slow-moving?
- How much demand occurs on an average day?
- What safety stock and reorder point should be maintained?
- Which products may be approaching stockout risk?

The project addresses these questions using SQL-based analysis and an interactive Power BI dashboard.

---

## Project Objectives

1. Build a structured retail analytics data model.
2. Analyze revenue, profit, orders, units, and customer behavior.
3. Use advanced SQL techniques for business analysis.
4. Segment products using demand velocity.
5. Calculate safety stock and reorder points.
6. Compare inventory with reorder thresholds when inventory snapshots are available.
7. Present KPIs and trends through Power BI.

---

## Data Model

The project follows a **star-schema approach**.

```text
                         ┌───────────────┐
                         │   dim_date    │
                         └───────┬───────┘
                                 │
                                 │
┌────────────────┐        ┌──────▼──────┐        ┌────────────────┐
│  dim_customer  │───────►│  fact_sales │◄───────│  dim_product   │
└────────────────┘        └──────┬──────┘        └────────────────┘
                                 │
                                 │
                         ┌───────▼───────┐
                         │   dim_store   │
                         └───────────────┘

                         ┌─────────────────────────┐
                         │ fact_inventory_snapshot │
                         └─────────────────────────┘
                              │          │
                              ▼          ▼
                         dim_product  dim_store
```

### Dimension Tables

| Table | Purpose |
|---|---|
| `dim_date` | Calendar, month, quarter and year analysis |
| `dim_product` | Product, category, pricing and lead-time attributes |
| `dim_customer` | Customer segment, region and city |
| `dim_store` | Store, region and store type |

### Fact Tables

| Table | Purpose |
|---|---|
| `fact_sales` | Transaction-level sales and profit |
| `fact_inventory_snapshot` | Current stock and inventory movement snapshots |

---

## SQL Analysis

### Core KPIs

- Total Revenue
- Total Profit
- Profit Margin %
- Total Units Sold
- Total Orders
- Distinct Customers
- Average Order Value
- Revenue by Region
- Revenue by Category

### Advanced SQL

The project demonstrates:

- `JOIN`
- `GROUP BY`
- `HAVING`
- CTEs
- Subqueries
- Conditional logic
- Window functions
- `RANK()`
- `DENSE_RANK()`
- `LAG()`
- Rolling calculations
- Month-over-month growth
- Product contribution %
- Customer ranking
- Repeat-customer analysis
- Demand velocity
- Statistical demand variation

Example:

```sql
DENSE_RANK() OVER (
    PARTITION BY category
    ORDER BY revenue DESC
) AS category_rank
```

This ranks products within their respective categories rather than only ranking them globally.

---

## Demand & Inventory Analytics

### Demand Segmentation

Products are classified using demand velocity:

```text
Fast-Moving    → Top velocity bucket
Medium-Moving  → Middle velocity buckets
Slow-Moving    → Bottom velocity bucket
```

### Average Daily Demand

```text
Average Daily Demand
= Total Units Sold / Active Selling Days
```

### Safety Stock

The project uses:

```text
Safety Stock
= Z × σ(daily demand) × √Lead Time
```

where `Z = 1.65` represents an approximately 95% service-level assumption.

### Reorder Point

```text
Reorder Point
= Average Daily Demand × Lead Time + Safety Stock
```

These assumptions are documented so they can be changed for a different service level or business context.

---

## Power BI Dashboard

The recommended report contains four pages.

### 1. Executive Summary

**KPIs**

- Total Revenue
- Total Profit
- Profit Margin %
- Total Orders
- Units Sold
- Average Order Value

**Visuals**

- Revenue trend
- Profit trend
- Revenue by category
- Revenue by region
- Top products

### 2. Sales & Customer Analysis

- Monthly sales trend
- Revenue by region
- Customer segment contribution
- Average order value
- Repeat customer rate
- Top customers

### 3. Product & Demand Analysis

- Product revenue
- Category performance
- Top-N products
- Product revenue contribution
- Fast/Medium/Slow-moving products
- Average daily demand

### 4. Inventory Health

- Current stock
- Safety stock
- Reorder point
- Stock vs reorder point
- Products at stockout risk
- Inventory movement

> The final repository should include screenshots from the actual Power BI report in `docs/screenshots/`.

---

## DAX Measures

The DAX library is documented separately in [`powerbi/dax_measures.md`](powerbi/dax_measures.md).

Core measures include:

```text
Total Revenue
Total Profit
Profit Margin %
Total Units Sold
Total Orders
Average Order Value
Previous Month Revenue
MoM Revenue Growth %
YTD Revenue
Repeat Customer Rate
Product Revenue Rank
Average Daily Velocity
Current Stock
Reorder Point
Stockout Risk Flag
```

---

## Key Business Questions

The SQL and Power BI analysis are designed to answer:

1. What is total revenue and profit?
2. Which category generates the most revenue?
3. Which products are the top performers?
4. What is the month-over-month revenue growth?
5. Which customers are repeat buyers?
6. Which regions generate the highest revenue?
7. Which products contribute the largest share of revenue?
8. Which products are fast-moving?
9. What is the average daily demand for each product?
10. What safety stock is required?
11. What is the reorder point?
12. Which products are below their reorder threshold?

---

## Repository Structure

```text
retail-demand-sales-analytics-dashboard/
│
├── README.md
├── .gitignore
├── LICENSE
│
├── data/
│   └── README.md
│
├── sql/
│   ├── 01_schema.sql
│   ├── 02_seed_data.sql
│   ├── 03_analytical_queries.sql
│   ├── 04_demand_segmentation.sql
│   ├── 05_advanced_interview_queries.sql
│   └── 06_inventory_analysis.sql
│
├── powerbi/
│   ├── RetailDemandDashboard.pbix
│   ├── dax_measures.md
│   └── README.md
│
└── docs/
    └── screenshots/
        ├── executive_summary.png
        ├── sales_customer_analysis.png
        ├── product_demand_analysis.png
        └── inventory_health.png
```

---

## How to Run

### 1. Clone the repository

```bash
git clone https://github.com/<your-username>/retail-demand-sales-analytics-dashboard.git
cd retail-demand-sales-analytics-dashboard
```

### 2. Create the MySQL database

```bash
mysql -u root -p < sql/01_schema.sql
```

### 3. Load the data

Place the actual CSV files in `data/` and update the paths in `sql/02_seed_data.sql`.

Then run:

```bash
mysql -u root -p retail_analytics < sql/02_seed_data.sql
```

### 4. Run the SQL analysis

```bash
mysql -u root -p retail_analytics < sql/03_analytical_queries.sql
mysql -u root -p retail_analytics < sql/04_demand_segmentation.sql
mysql -u root -p retail_analytics < sql/05_advanced_interview_queries.sql
mysql -u root -p retail_analytics < sql/06_inventory_analysis.sql
```

### 5. Open Power BI

Open:

```text
powerbi/RetailDemandDashboard.pbix
```

Update the data-source path if required, refresh the model, and verify the relationships before publishing screenshots.

---

## Interview Talking Points

### Why MySQL?

MySQL was used for structured storage, relational modeling, KPI extraction, and analytical SQL.

### Why a star schema?

Separating facts from dimensions improves analytical querying, makes relationships easier to manage, and creates a clean model for Power BI.

### Why demand velocity?

Historical units sold alone do not show how quickly products move. Velocity normalizes demand by active selling days and helps classify products.

### Why safety stock?

Demand varies from day to day. Safety stock provides a buffer against demand variability during the replenishment lead time.

### What would you improve in production?

- Use a scheduled ETL/ELT pipeline.
- Add real inventory transactions rather than only snapshots.
- Add supplier and purchase-order data.
- Add forecast models for future demand.
- Add automated data-quality checks.
- Parameterize the service-level assumption.
- Connect Power BI to a refreshed database instead of static files.

---

## Resume Version

**Retail Demand & Sales Analytics Dashboard | MySQL, SQL, Power BI**

- Analyzed **8,000+ retail transactions** using MySQL to evaluate revenue, profitability, customer behavior, product performance, and regional sales trends.
- Designed a **star-schema data model** and developed analytical SQL using CTEs, window functions, ranking, time-series analysis, and customer/product segmentation.
- Built Power BI dashboards with DAX-based KPIs and **demand/inventory analytics**, including demand velocity, safety stock, reorder points, and stockout-risk indicators.

> Replace the 8,000+ figure with the exact count from the final dataset if it differs.

---

## Project Status

| Component | Status |
|---|---|
| SQL schema | Ready |
| KPI analysis | Ready |
| Advanced SQL | Ready |
| Demand segmentation | Ready |
| Inventory logic | Ready |
| DAX documentation | Ready |
| Actual dataset | Add final dataset |
| Power BI `.pbix` | Add final report |
| Dashboard screenshots | Add final screenshots |
| Data-backed insights | Add after final analysis |

---

## License

This project is intended for educational and portfolio purposes.
