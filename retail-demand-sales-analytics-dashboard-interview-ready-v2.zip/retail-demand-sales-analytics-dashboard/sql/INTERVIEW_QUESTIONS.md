# SQL Interview Questions

Use these questions to explain the project during interviews.

## Basic
1. Calculate total revenue.
2. Calculate total profit and profit margin.
3. Find the top 10 products by revenue.
4. Find revenue by category.
5. Calculate average order value.

## Intermediate
6. Find repeat customers.
7. Calculate revenue by region.
8. Find products with revenue above average.
9. Calculate monthly revenue.
10. Calculate customer revenue contribution.

## Advanced
11. Find the top 3 products within each category.
12. Calculate month-over-month revenue growth using `LAG()`.
13. Calculate a 7-day rolling revenue metric.
14. Rank customers within each region.
15. Calculate product contribution to total revenue.
16. Segment products using `NTILE()`.
17. Calculate daily demand variation using `STDDEV_SAMP()`.
18. Calculate safety stock.
19. Calculate reorder point.
20. Identify products whose inventory is below the reorder point.

## Interview explanation

For every query, be prepared to explain:

- What business question it answers.
- Why you chose the SQL technique.
- What assumptions were made.
- How the result would be validated.
- How the output would be used in Power BI.
